# SAMA5D4 LED Blink Example

Sample script to blink the Blue LED on a "SAMA5D4 XPLAINED ULTRA" board

Run qml script using sam-ba tool, for example:
    On Windows:
        ..\..\..\sam-ba -x blink.qml
    On Linux:
        ../../../sam-ba -x blink.qml
