import sys
from xmodem import run

if __name__ == '__main__':
    sys.exit(run())